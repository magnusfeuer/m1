Croptal AB
Scheelegatan 11
11228 Stockholm
Bj�rn Evestrand
08-4490538
070-7715300
bjorn@croptal.se



----------------------------PCB specification---------------------------------

Board identification:          	Magden OBD Rev 1.1
                                 
Board size:    			36x62 mm                	

PCB specification:            	PERFAG 3B
Type of board:                	Multilayer board, 4 layers

Type of laminate:              	FR4 RoHs

Laminate thickness:            	1,6 mm

Thickness of copper foil:  	35 um  Ready board

Build-up of MLB:            	Layer order. Top view.

    


--------------------------End of PCB specification----------------------------


--------------------- EXPLANATION OF PLOT AND DRILL FILES --------------------
--------------------------------- FILES --------------------------------------

FILE NAME                       COMMENTS

Magden OBD Rev 1.1.ZIP          =  Extracting file

PHOTOPLOTTERDATA / GERBERDATA:

Magden OBD Rev 1.1-L1.PHO      	=  Top       , layer 1
Magden OBD Rev 1.1-L2.PHO      	=  Innerlayer, layer 2
Magden OBD Rev 1.1-L3.PHO      	=  Innerlayer, layer 3
Magden OBD Rev 1.1-L4.PHO      	=  Bottom    , layer 4
Magden OBD Rev 1.1-M1.PHO      	=  Mask, Top
Magden OBD Rev 1.1-M4.PHO      	=  Mask, Bottom
Magden OBD Rev 1.1-SST		=  Silkscreen top

DRILL-/CONTOURDATA:

Magden OBD Rev 1.1-B1.PHO		=  Border outline center line
 
Magden OBD Rev 1.1.DRL          =  Drill-/contourdata
Magden OBD Rev 1.1.LST          =  Drill Listing

                         SETUP FOR PLOT-/DRILLDATA

----------------------------- GERBER PLOT DATA--------------------------------

format                = RS-274-X                                       
